#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
ull Valid_Check(const string inp, bool &negative)
{
    ull dot=inp.size();
    ull x=0;
    if(inp[0]=='-')
    {
        negative=true;
        ++x;
    }
    for(; x<inp.size(); x++)
    {
        if((inp[x]-'0'<10) && (inp[x]-'0'>=0))
            continue;
        else if(inp[x]=='.' && dot==inp.size())
        {
            dot=x;
        }
        else
        {
            cout<<"Invalid input ";
            return 0;
        }
    }
//    cout<<dot<<"\n";
    return dot;
}
void addnum(string &Integer, string &Decimal, const string InpInt, const string InpDec)
{
    ull Carry=0;
    for(ull x=0; x<Decimal.size(); x++)
    {
        unsigned short sum=Decimal[x]+InpDec[x]-'0'-'0'+Carry;
        Decimal[x]=sum%10+'0';
        Carry=sum/10;
    }
    for(ull x=0; x<Integer.size(); x++)
    {
        unsigned short sum=Integer[x]+InpInt[x]-'0'-'0'+Carry;
        Integer[x]=sum%10+'0';
        Carry=sum/10;
    }
    if(Carry)
        Integer.append(1,(char)Carry+'0');
    return;
}
void subnum(string &Integer, string &Decimal, const string InpInt, const string InpDec)
{
    ull Carry=1;
    for(ull x=0; x<Decimal.size(); x++)
    {
        unsigned short sum=Decimal[x]-'0'+'9'-InpDec[x]+Carry;
        Decimal[x]=sum%10+'0';
        Carry=sum/10;
    }
    for(ull x=0; x<Integer.size(); x++)
    {
        unsigned short sum=Integer[x]-'0'+'9'-InpInt[x]+Carry;
        Integer[x]=sum%10+'0';
        Carry=sum/10;
    }
    return;
}
int main(int argc, char *argv[])
{
    string PosInt, PosDec, NegInt, NegDec;
    for(ull x=1; x<argc; x++)
    {
        string inp;
        inp+=argv[x];
        bool negative=false;
        ull dot=Valid_Check(inp,negative);
        if(!dot)
        {
            cout<<"at number "<<x<<"\n";
            cin.ignore();
            return 0;
        }
        string InpInt, InpDec;
        if(!negative)
            InpInt.append(inp.begin(),inp.begin()+dot);
        else
            InpInt.append(inp.begin()+1,inp.begin()+dot);
        if(dot!=inp.size())
            InpDec.append(inp.begin()+dot+1,inp.end());
        reverse(InpInt.begin(),InpInt.end());
        string SupDec;
        if(negative)
        {
            if(NegInt.size()<InpInt.size())
                NegInt.append(InpInt.size()-NegInt.size(),'0');
            else
                InpInt.append(NegInt.size()-InpInt.size(),'0');
            if(NegDec.size()<InpDec.size())
            {
                SupDec.append(InpDec.size()-NegDec.size(),'0');
                reverse(InpDec.begin(),InpDec.end());
                SupDec+=NegDec;
                NegDec=SupDec;
                addnum(NegInt,NegDec,InpInt,InpDec);
            }
            else
            {
                InpDec.append(NegDec.size()-InpDec.size(),'0');
                reverse(InpDec.begin(),InpDec.end());
                addnum(NegInt,NegDec,InpInt,InpDec);
            }
        }
        else
        {
            if(PosInt.size()<InpInt.size())
                PosInt.append(InpInt.size()-PosInt.size(),'0');
            else
                InpInt.append(PosInt.size()-InpInt.size(),'0');
            if(PosDec.size()<InpDec.size())
            {
                SupDec.append(InpDec.size()-PosDec.size(),'0');
                reverse(InpDec.begin(),InpDec.end());
                SupDec+=PosDec;
                PosDec=SupDec;
                addnum(PosInt,PosDec,InpInt,InpDec);
            }
            else
            {
                InpDec.append(PosDec.size()-InpDec.size(),'0');
                reverse(InpDec.begin(),InpDec.end());
                addnum(PosInt,PosDec,InpInt,InpDec);
            }
        }
    }
    // Let Pos==Neg
    reverse(PosDec.begin(),PosDec.end());
    reverse(NegDec.begin(),NegDec.end());
    if(PosDec.size()>NegDec.size())
    {
        NegDec.append(PosDec.size()-NegDec.size(),'0');
    }
    else if(NegDec.size()>PosDec.size())
    {
        PosDec.append(NegDec.size()-PosDec.size(),'0');
    }
    if(PosInt.size()>NegInt.size())
    {
        reverse(PosDec.begin(),PosDec.end());
        reverse(NegDec.begin(),NegDec.end());
        NegInt.append(PosInt.size()-NegInt.size(),'0');
        subnum(PosInt,PosDec,NegInt,NegDec);
        reverse(PosInt.begin(),PosInt.end());
        reverse(PosDec.begin(),PosDec.end());
        bool MSB=false;
        for(ull x=0; x<PosInt.size(); x++)
        {
            if(PosInt[x]!='0')
                MSB=true;
            if(MSB)
                cout<<PosInt[x];
        }
        long long LSB=PosDec.size()-1;
        for(; LSB>=0; LSB--)
        {
            if(PosDec[LSB]!='0')
                break;
        }
        if(LSB!=-1)
        {
            cout<<'.';
            for(long long x=0; x<=LSB; x++)
            {
                cout<<PosDec[x];
            }
        }
        cout<<"\n";
    }
    else if(PosInt.size()<NegInt.size())
    {
        reverse(PosDec.begin(),PosDec.end());
        reverse(NegDec.begin(),NegDec.end());
        cout<<"-";
        PosInt.append(NegInt.size()-PosInt.size(),'0');
        subnum(NegInt,NegDec,PosInt,PosDec);
        reverse(NegInt.begin(),NegInt.end());
        reverse(NegDec.begin(),NegDec.end());
        bool MSB=false;
        for(ull x=0; x<NegInt.size(); x++)
        {
            if(NegInt[x]!='0')
                MSB=true;
            if(MSB)
                cout<<NegInt[x];
        }
        long long LSB=NegDec.size()-1;
        for(; LSB>=0; LSB--)
        {
            if(NegDec[LSB]!='0')
                break;
        }
        if(LSB!=-1)
        {
            cout<<'.';
            for(long long x=0; x<=LSB; x++)
            {
                cout<<NegDec[x];
            }
        }
        cout<<"\n";
    }
    else
    {
//        cout<<PosInt<<" "<<NegInt<<"\n";
        for(long long x=PosInt.size()-1; x>=0; x--)
        {
//            cout<<x<<"x\n";
//            cout<<"P"<<PosInt[x]<<"N"<<NegInt[x]<<"\n";
            if(PosInt[x]>NegInt[x])
            {
                reverse(PosDec.begin(),PosDec.end());
                reverse(NegDec.begin(),NegDec.end());
                subnum(PosInt,PosDec,NegInt,NegDec);
                reverse(PosInt.begin(),PosInt.end());
                reverse(PosDec.begin(),PosDec.end());
                bool MSB=false;
                for(ull x=0; x<PosInt.size(); x++)
                {
                    if(PosInt[x]!='0')
                        MSB=true;
                    if(MSB)
                        cout<<PosInt[x];
                }
                long long LSB=PosDec.size()-1;
                for(; LSB>=0; LSB--)
                {
                    if(PosDec[LSB]!='0')
                        break;
                }
                if(LSB!=-1)
                {
                    cout<<'.';
                    for(long long x=0; x<=LSB; x++)
                    {
                        cout<<PosDec[x];
                    }
                }
                cout<<"\n";
                return 0;
            }
            else if(PosInt[x]<NegInt[x])
            {
                reverse(PosDec.begin(),PosDec.end());
                reverse(NegDec.begin(),NegDec.end());
                cout<<"-";
                subnum(NegInt,NegDec,PosInt,PosDec);
                reverse(NegInt.begin(),NegInt.end());
                reverse(NegDec.begin(),NegDec.end());
                bool MSB=false;
                for(ull x=0; x<NegInt.size(); x++)
                {
                    if(NegInt[x]!='0')
                        MSB=true;
                    if(MSB)
                        cout<<NegInt[x];
                }
                long long LSB=NegDec.size()-1;
                for(; LSB>=0; LSB--)
                {
                    if(NegDec[LSB]!='0')
                        break;
                }
                if(LSB!=-1)
                {
                    cout<<'.';
                    for(long long x=0; x<=LSB; x++)
                    {
                        cout<<NegDec[x];
                    }
                }
                cout<<"\n";
                return 0;
            }
        }
        if(PosDec.compare(0,PosDec.size(),NegDec,0,PosDec.size())>0)
        {
            reverse(PosDec.begin(),PosDec.end());
            reverse(NegDec.begin(),NegDec.end());
            subnum(PosInt,PosDec,NegInt,NegDec);
            reverse(PosInt.begin(),PosInt.end());
            reverse(PosDec.begin(),PosDec.end());
            bool MSB=false;
            for(ull x=0; x<PosInt.size(); x++)
            {
                if(PosInt[x]!='0')
                    MSB=true;
                if(MSB)
                    cout<<PosInt[x];
            }
            long long LSB=PosDec.size()-1;
            for(; LSB>=0; LSB--)
            {
                if(PosDec[LSB]!='0')
                    break;
            }
            if(LSB!=-1)
            {
                cout<<'.';
                for(long long x=0; x<=LSB; x++)
                {
                    cout<<PosDec[x];
                }
            }
            cout<<"\n";
        }
        else if(PosDec.compare(0,PosDec.size(),NegDec,0,PosDec.size())<0)
        {
            cout<<"-";
            reverse(PosDec.begin(),PosDec.end());
            reverse(NegDec.begin(),NegDec.end());
            subnum(NegInt,NegDec,PosInt,PosDec);
            reverse(NegInt.begin(),NegInt.end());
            reverse(NegDec.begin(),NegDec.end());
            bool MSB=false;
            for(ull x=0; x<NegInt.size(); x++)
            {
                if(NegInt[x]!='0')
                    MSB=true;
                if(MSB)
                    cout<<NegInt[x];
            }
            long long LSB=NegDec.size()-1;
            for(; LSB>=0; LSB--)
            {
                if(NegDec[LSB]!='0')
                    break;
            }
            if(LSB!=-1)
            {
                cout<<'.';
                for(long long x=0; x<=LSB; x++)
                {
                    cout<<NegDec[x];
                }
            }
            cout<<"\n";
        }
        else
            cout<<0<<'\n';
    }
    return 0;
}
