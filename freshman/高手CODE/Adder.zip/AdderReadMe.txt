General Instructions:
1. Place Adder.exe under the same directory of Command Prompt(cmd)
2. Type: Adder.exe [] [] [] ...(replace [] with numbers you want to add)

Elementary Instructions for Command Prompt:
Switch between disks: [disk_label]:
Get into the folder under current directory: cd [first_level]/[second_level]/[third_level]
Go back to the upper level: cd..
For more information, please visit: https://technet.microsoft.com/en-us/library/bb490890.aspx?f=255&MSPPError=-2147217396

Input Format: Any
Valid Input: Any numbers

Valid Examples:
1234
0000000000000000000000000000012321222222222222222222222222222222222222223123234324234242342423423421231723846237.123
-123237.2342343487452982371212
-.12893642394263
-0000000000000000000000000000012321222222222222222222222222222222222222223123234324234242342423423421231723846237.12 3 -1

Features:
-Supports both positive and negative numbers
-Supports decimal numbers
-No length limitation
-Input validity check with details

Source Language: C++
Compiler Information: g++ (gcc 5.3.0)
Compile settings: -Wall -Wextra -std=c++17 -O3
Platform: Windows 10 Pro Insider Preview - Build 14291.1001