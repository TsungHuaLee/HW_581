Input Format: Any

Valid Format: Account@Domain
	      Account:All numbers, alphabets(capitalized/non-capitalized), '_', and '.'
	      Domain:All numbers, alphabets(capitalized/non-capitalized), '_', and '.'(at least 1)

Valid Examples:
TeST@gMail.com                  => Valid
test_two@gmail.com              => Valid
123456@gmail.com                => Valid
1.2.@.__edcdds                  => Valid
____@__.                        => Valid

Source Language: C++
Compiler Information: g++ (gcc 5.3.0)
Compile settings: -Wall -Wextra -std=c++17 -O3
Platform: Windows 10 Pro Insider Preview - Build 14291.1001